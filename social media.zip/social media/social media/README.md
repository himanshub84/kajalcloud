# Social-Network
A social networking Django application (similar to Twitter) written in Python, HTML, CSS &amp; JavaScript.

[Watch on YouTube](https://www.youtube.com/watch?v=d4_sidaZUZY)
